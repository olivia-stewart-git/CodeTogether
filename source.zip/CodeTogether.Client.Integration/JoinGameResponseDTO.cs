﻿namespace CodeTogether.Client.Integration
{
	public class JoinGameResponse
	{
		public required int ServerId { get; set; }
	}
}
