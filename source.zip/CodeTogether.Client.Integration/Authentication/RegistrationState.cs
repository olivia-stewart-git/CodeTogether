﻿namespace CodeTogether.Client.Integration.Authentication;

public enum RegistrationState
{
	Success,
	Failure
}