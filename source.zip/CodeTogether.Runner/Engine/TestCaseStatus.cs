﻿namespace CodeTogether.Runner.Engine;

public enum TestCaseStatus
{
	Success,
	Failure,
	Error
}