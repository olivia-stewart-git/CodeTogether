﻿namespace CodeTogether.Data.DataAccess;

/// <summary>
/// Any model in database
/// </summary>
public interface IDbModel
{
}