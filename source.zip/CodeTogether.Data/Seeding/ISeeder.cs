﻿namespace CodeTogether.Data.Seeding;

public interface ISeeder
{
	public void Seed();
}