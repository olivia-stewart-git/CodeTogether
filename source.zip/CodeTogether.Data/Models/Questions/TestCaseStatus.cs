﻿namespace CodeTogether.Data.Models.Questions;

public enum TestCaseStatus
{
	Success,
	Failure,
	Error
}