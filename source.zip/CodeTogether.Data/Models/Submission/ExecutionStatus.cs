﻿namespace CodeTogether.Runner.Engine;

public enum ExecutionStatus
{
	None,
	Success,
	Failure,
	Error
}