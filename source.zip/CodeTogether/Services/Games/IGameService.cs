﻿namespace CodeTogether.Services.Games
{
	public interface IGameService
	{
	}
}
