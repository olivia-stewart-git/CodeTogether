﻿namespace CodeTogether.Services.Games
{
	// To hold the state of all ongoing games on this server in memory
	public class GameService : IGameService
	{
	}
}
